//
//  DetailViewController.swift
// Project: LyAlan-HW10
// EID: al49725
// Course: CS371L

import UIKit

class DetailViewController: UIViewController {
    var delegate: UIViewController!

    @IBOutlet weak var imageView: UIImageView!
    var currImage: UIImage!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        imageView.image = currImage
    }
}
