//
//  ViewController.swift
// Project: LyAlan-HW2
// EID: al49725
// Course: CS371L

//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {


    @IBOutlet weak var userIdInput: UITextField!
    @IBOutlet weak var passwordInput: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var loginText: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        userIdInput.delegate = self
        passwordInput.delegate = self
    }
    
    func textFieldShouldReturn(_ textField:UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    @IBAction func buttonPressed(_ sender: Any) {
        let user = userIdInput.text!
        let password = passwordInput.text!
        if(user.isEmpty || password.isEmpty){
            loginText.text = "Invalid login"
        }
        else{
            loginText.text = user + " logged in"
        }
    }
    
}

