//
//  ViewController.swift
// Project: LyAlan-HW5
// EID: al49725
// Course: CS371L

import UIKit
class Pizza {
    var pSize: String = ""
    var crust: String = ""
    var cheese: String = ""
    var meat: String = ""
    var veggies: String = ""
    
    init(pSize:String, crust:String, cheese:String, meat:String, veggies:String) {
        self.pSize = pSize
        self.crust = crust
        self.cheese = cheese
        self.meat = meat
        self.veggies = veggies
    }
    func showPizza()->String {
        return "\(pSize)\n\t \(crust)\n\t \(cheese)\n\t \(meat)\n\t \(veggies)"
    }
}

protocol TableManager {
    func addPizza(pSize:String, crust:String, cheese:String, meat:String, veggies:String)
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, TableManager {
    
    
    @IBOutlet weak var madePizzas: UITableView!
    let textCellIdentifier = "TextCell"

    var pizzaList:[Pizza] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        madePizzas.delegate = self
        madePizzas.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        madePizzas.reloadData()
    }
    
    func tableView(_ madePizzas: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pizzaList.count
    }
    
    func tableView(_ madePizzas: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = madePizzas.dequeueReusableCell(withIdentifier: textCellIdentifier, for:indexPath as IndexPath)
        let row = indexPath.row
        cell.textLabel?.text = pizzaList[row].showPizza()
        return cell
    }
        
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "PizzaScreen",
           let nextVC = segue.destination as? CreatePizza
        {
            nextVC.delegate = self
        }
    }
    
    func addPizza(pSize: String, crust: String, cheese: String, meat: String, veggies: String) {
        
        let newPizza = Pizza(pSize: pSize, crust: crust, cheese: cheese, meat: meat, veggies: veggies)
        pizzaList.append(newPizza)
    }

}

