//
//  CalculateViewController.swift
// Project: LyAlan-HW4
// EID: al49725
// Course: CS371L
//

import UIKit

class CalculateViewController: UIViewController {
    
    @IBOutlet weak var operatorSymbol: UILabel!
    
    @IBOutlet weak var firstNumber: UITextField!
    @IBOutlet weak var secondNumber: UITextField!
    var changedOperator = "Operator"
    @IBOutlet weak var answer: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        operatorSymbol.text = parseSymbol()
    }
    
    @IBAction func calculateEquation(_ sender: Any) {
        if (Float(secondNumber.text ?? "") ?? 0) == 0{
            answer.text = "Divided by 0/ Invalid"
        }
        
        else if  let first = Int(firstNumber.text ?? ""),  let second = Int(secondNumber.text ?? "") {
            if operatorSymbol.text == "+"{
                answer.text = String(first + second)
            }
            else if operatorSymbol.text == "-"{
                answer.text = String(first - second)
            }
            else if operatorSymbol.text == "*"{
                answer.text = String(first * second)
            }
            else {
                answer.text = String(first / second)
            }
        }
        else if let first = Float(firstNumber.text ?? ""),  let second = Float(secondNumber.text ?? "") {
            if operatorSymbol.text == "+"{
                answer.text = String(first + second)
            }
            else if operatorSymbol.text == "-"{
                answer.text = String(first - second)
            }
            else if operatorSymbol.text == "*"{
                answer.text = String(first * second)
            }
            else {
                answer.text = String(first / second)
            }
        }
    }
    
    func parseSymbol()->String{
        if changedOperator == "Add"{
            return "+"
        }
        else if changedOperator == "Subtract"{
            return "-"
        }
        else if changedOperator == "Multiply"{
            return "*"
        }
        else if changedOperator == "Divide"{
            return "/"
        }
        else{
            return "Operator"
        }
    }

}
