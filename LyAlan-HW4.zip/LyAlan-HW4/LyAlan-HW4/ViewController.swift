//
//  ViewController.swift
// Project: LyAlan-HW4
// EID: al49725
// Course: CS371L
//

import UIKit

public let operations = ["Add", "Subtract", "Multiply", "Divide"]

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableOperator: UITableView!
    let textCellIdentifier = "TextCell"

    
    func tableView(_ tableOperator: UITableView, numberOfRowsInSection section: Int) -> Int {
        return operations.count

    }
    
    func tableView(_ tableOperator: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableOperator.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath as IndexPath)
        let row = indexPath.row
        cell.textLabel?.text = operations[row]
        
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableOperator.delegate = self
        tableOperator.dataSource = self
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SegueMath",
           let destination = segue.destination as? CalculateViewController,
           let index = tableOperator.indexPathForSelectedRow?.row {
            destination.changedOperator = operations[index]
        }
    }

}

