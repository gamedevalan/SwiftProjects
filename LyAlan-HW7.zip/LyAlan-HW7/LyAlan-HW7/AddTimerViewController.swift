//
//  AddTimerViewController.swift
// Project: LyAlan-HW7
// EID: al49725
// Course: CS371L

import UIKit

class AddTimerViewController: UIViewController {

    @IBOutlet weak var eventTextField: UITextField!
    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var totalTimeTextField: UITextField!
    var delegate: UIViewController!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func saveButton(_ sender: Any) {
        let lastVC = delegate as! TimerManager
        lastVC.addTimer(event: eventTextField.text!, location: locationTextField.text!, time: Int(totalTimeTextField.text ?? "") ?? 0)

    }
}
