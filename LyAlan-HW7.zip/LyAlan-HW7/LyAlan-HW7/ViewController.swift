//
//  ViewController.swift
// Project: LyAlan-HW7
// EID: al49725
// Course: CS371L

import UIKit
class Timers{
    var event:String
    var location:String
    var time:Int
    
    init(event: String, location: String, time: Int) {
        self.event = event
        self.location = location
        self.time = time
    }
    
    func decrementTime(){
        time -= 1
    }
}
protocol TimerManager {
    func addTimer(event: String, location: String, time: Int)
}

class TimerCell: UITableViewCell{
    
    @IBOutlet weak var eventCellText: UILabel!
    @IBOutlet weak var locationCellText: UILabel!
    @IBOutlet weak var timeCellText: UILabel!
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, TimerManager{
    
    var timerList:[Timers] = []
    
    @IBOutlet weak var madeTimers: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return timerList.count
    }
    
    func tableView(_ madeTimers: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = madeTimers.dequeueReusableCell(withIdentifier: "TimerTable-ViewCell", for:indexPath as IndexPath) as! TimerCell
        let row = indexPath.row
        cell.eventCellText?.text = "Event: \(timerList[row].event)"
        cell.locationCellText?.text = "Location: \(timerList[row].location)"
        cell.timeCellText?.text = "Remaining Time(s): \(String(timerList[row].time))"
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        madeTimers.delegate = self
        madeTimers.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        madeTimers.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AddTimerSeg",
           let nextVC = segue.destination as? AddTimerViewController
        {
            nextVC.delegate = self
        }
        if segue.identifier == "CountdownSeg",
           let nextVC = segue.destination as? CountdownViewController,
           let index = madeTimers.indexPathForSelectedRow?.row {
            nextVC.currTimer = timerList[index]
        }
    }
    
    func addTimer(event: String, location: String, time: Int){
        let newTimer = Timers(event:event, location:location, time: time)
        timerList.append(newTimer)
    }

}

