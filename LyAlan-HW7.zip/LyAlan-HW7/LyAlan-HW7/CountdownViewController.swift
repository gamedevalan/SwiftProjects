//
//  CountdownViewController.swift
// Project: LyAlan-HW7
// EID: al49725
// Course: CS371L

import UIKit

class CountdownViewController: UIViewController {

    @IBOutlet weak var eventText: UILabel!
    @IBOutlet weak var locationText: UILabel!
    @IBOutlet weak var remainTimeText: UILabel!
    
    var eventWhat:String = ""
    var locationWhere:String = ""
    var timeRemain:Int = 0
    
    var currTimer:Timers!
    var done:Bool = false;
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        eventText.text = currTimer.event
        locationText.text = currTimer.location
        remainTimeText.text = String(currTimer.time)
        done = false;
        startCountdown()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        done = true
    }
    
    func startCountdown(){
        let queue = DispatchQueue.global()
        queue.async {
            while self.currTimer.time > 0 && self.done == false {
                self.currTimer.decrementTime()
                DispatchQueue.main.async {
                    self.remainTimeText.text = String(self.currTimer.time)
                }
                sleep(1) // Pause the execution for 1 second
            }
        }
    }


}
