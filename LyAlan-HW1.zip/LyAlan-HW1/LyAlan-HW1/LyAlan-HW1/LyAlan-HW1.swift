// Project: LyAlan-HW1
// EID: al49725
// Course: CS371L

class Weapon{
    var type:String
    var damage:Int
    
    init(weaponType:String){
        type = weaponType
        
        if weaponType == "dagger"{
            damage = 4
        }
        else if weaponType == "axe"||weaponType == "staff"{
            damage = 6
        }
        else if weaponType == "sword"{
            damage = 10
        }
        else{ // no weapon
            damage = 1
        }
    }
}

class Armor{
    var type:String
    var armorClass:Int
    
    init(armorType:String){
        type = armorType
        
        if armorType == "plate"{
            armorClass = 2
        }
        else if armorType == "chain"{
            armorClass = 5
        }
        else if armorType == "leather"{
            armorClass = 8
        }
        else { // no weapon
            armorClass = 10
        }
    }
}

class RPGCharacter{
    var name:String
    var health:Int
    var maxHealth:Int
    var spellPoints:Int
    var weapon:Weapon
    var armor:Armor
    
    init(charName:String, charHealth:Int, charMaxHealth:Int, charSpellPoints:Int, charWeapon:Weapon, charArmor:Armor) {
        name = charName
        health = charHealth
        maxHealth = charMaxHealth
        spellPoints = charSpellPoints
        weapon = charWeapon
        armor = charArmor
    }
    
    func wield(weaponObject weaponName:Weapon){
        weapon = weaponName
        print("\(name) is now wielding a(n) \(weaponName.type)")
    }
    
    func unwield(){
        weapon = Weapon(weaponType: "one")
        print("\(name) is no longer wielding anything.")
    }
    
    func putOnArmor(armorObject armorName:Armor){
        armor = armorName
        print("\(name) is now wearing \(armorName.type)")
    }
    
    func takeOffArmor(){
        weapon = Weapon(weaponType: "none")
        print("\(name) is no longer wearing anything.")
    }
    
    func show(){
        print(name)
        print("\tCurrent Health: \(health)")
        print("\tCurrent Spell Points: \(spellPoints)")
        print("\tWielding: \(weapon.type)")
        print("\tWearing: \(armor.type)")
        print("\tArmor Class: \(armor.armorClass)")

    }
    
    func fight(opponent: RPGCharacter){
        print("\(name) attacks \(opponent.name) with a(n) \(weapon.type)")
        opponent.health -= weapon.damage
        print("\(name) does \(weapon.damage) damage to \(opponent.name)")
        print("\(opponent.name) is now down to \(opponent.health) health")
        checkForDefeat(character: opponent)
    }
    
    func checkForDefeat(character:RPGCharacter){
        if(character.health <= 0){
            print("\(character.name) has been defeated!")
        }
    }
}

class Fighter:RPGCharacter{
    init(name:String){
        super.init(charName: name, charHealth: 40, charMaxHealth: 40, charSpellPoints: 0, charWeapon:Weapon(weaponType: "none"), charArmor:Armor(armorType: "none"))
    }
}

class Wizard:RPGCharacter{
    init(name:String){
        super.init(charName: name, charHealth: 16, charMaxHealth: 16, charSpellPoints: 20, charWeapon:Weapon(weaponType: "none"), charArmor:Armor(armorType: "none"))
    }
    
    override func wield(weaponObject weaponName:Weapon){
        if(weaponName.type == "dagger" || weaponName.type == "staff" || weaponName.type == "none"){
            weapon = weaponName
            print("\(name) is now wielding a(n) \(weaponName.type)")
        }
        else{
            print("Weapon not allowed for this character class.")
        }
    }
    
    override func putOnArmor(armorObject armorName:Armor){
        print("Armor not allowed for this character class.")
    }
    
    func castSpell(spellName:String, target:RPGCharacter){
        var cost:Int
        var effect:Int
        print("\(name) casts \(spellName) at \(target.name)")
        if spellName == "Fireball"{
            cost = 3
            effect = 5
        }
        else if spellName == "Lightning Bolt"{
            cost = 10
            effect = 10
        }
        else if spellName == "Heal"{ // in case more wants to be added
            cost = 6
            effect = 6
        }
        else{
            print("Unknown spell name. Spell failed.")
            return
        }
        if(cost > spellPoints){
            print("Insufficient spell points")
            return
        }
        spellPoints -= cost
        if(spellName == "Heal"){
            if(target.health + effect > target.maxHealth){
                effect = target.maxHealth - target.health
                target.health = target.maxHealth
            }
            else{
                target.health += effect
            }
            print("\(name) heals \(target.name) for \(effect) health points")
            print("\(target.name) is now at \(target.health) health.")
        }
        else{
            target.health -= effect
            print("\(name) does \(effect) damage to \(target.name)")
            print("\(target.name) is now down to \(target.health) health")
            checkForDefeat(character: target)
        }
    }
}

// top level code

let plateMail = Armor(armorType: "plate")
let chainMail = Armor(armorType: "chain")
let sword = Weapon(weaponType: "sword")
let staff = Weapon(weaponType: "staff")
let axe = Weapon(weaponType: "axe")

let gandalf = Wizard(name: "Gandalf the Grey")
gandalf.wield(weaponObject: staff)

let aragorn = Fighter(name: "Aragorn")
aragorn.putOnArmor(armorObject: plateMail)
aragorn.wield(weaponObject: axe)

gandalf.show()
aragorn.show()

gandalf.castSpell(spellName: "Fireball", target: aragorn)
aragorn.fight(opponent: gandalf)

gandalf.show()
aragorn.show()

gandalf.castSpell(spellName: "Lightning Bolt", target: aragorn)
aragorn.wield(weaponObject: sword)

gandalf.show()
aragorn.show()

gandalf.castSpell(spellName: "Heal", target: gandalf)
aragorn.fight(opponent: gandalf)

gandalf.fight(opponent: aragorn)
aragorn.fight(opponent: gandalf)

gandalf.show()
aragorn.show()
