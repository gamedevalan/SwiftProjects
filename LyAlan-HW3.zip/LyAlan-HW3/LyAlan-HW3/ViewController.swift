//
//  ViewController.swift
// Project: LyAlan-HW3
// EID: al49725
// Course: CS371L
//
import UIKit

protocol TextChanger {
    func changeText(newWord:String)
    func changeColor(newColor:UIColor)
}

class ViewController: UIViewController, TextChanger {
    
    @IBOutlet weak var textField: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SegueText",
           let nextVC = segue.destination as? WordChangeViewController
        {
            nextVC.delegate = self
            nextVC.prevName = textField.text!
        }
        
        if segue.identifier == "SegueColor",
           let nextVC = segue.destination as? ColorChangeViewController
        {
            nextVC.delegate = self
        }
    }
    
    func changeText(newWord:String){
        textField.text = newWord
    }
    
    func changeColor(newColor:UIColor){
        textField.backgroundColor = newColor
    }
}

