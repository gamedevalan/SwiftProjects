//
//  AuthViewController.swift
// Project: LyAlan-HW6
// EID: al49725
// Course: CS371L

import UIKit
import FirebaseAuth


class LoginViewController: UIViewController {

    @IBOutlet weak var userField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    @IBOutlet weak var confirmField: UITextField!
    @IBOutlet weak var confirmLabel: UILabel!
    
    @IBOutlet weak var authType: UISegmentedControl!
    
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var statusText: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        Auth.auth().addStateDidChangeListener() {
            (auth, user) in
            if user != nil {
                self.performSegue(withIdentifier: "AuthSeg", sender: nil)
                self.userField.text = nil
                self.passwordField.text = nil
                self.confirmField.text = nil

            }
        }
        loginState(val: true)
    }
    
    func loginState(val:Bool){
        confirmField.isHidden = val
        confirmLabel.isHidden = val
        signInButton.isHidden = !val
        signUpButton.isHidden = val
    }
    
    @IBAction func authSegment(_ sender: Any) {
        switch authType.selectedSegmentIndex {
        case 0:
            loginState(val: true)
        case 1:
            loginState(val: false)
        default:
            loginState(val: true)
        }
    }
    
    @IBAction func signInPressed(_ sender: Any) {
        Auth.auth().signIn(withEmail: userField.text!, password: passwordField.text!) {
            
            (authResult,error) in
            if let error = error as NSError? {
                self.statusText.text = "\(error.localizedDescription)"
            } else {
                self.statusText.text = ""
            }
        }
    }
    
    @IBAction func signUpPressed(_ sender: Any) {
        if(confirmField.text == passwordField.text){
            Auth.auth().createUser(withEmail: userField.text!, password: passwordField.text!) {
                (authResult, error) in
                if let error = error as NSError? {
                    self.statusText.text = "\(error.localizedDescription)"
                } else {
                    self.statusText.text = ""
                }
            }
        }
    }
}
