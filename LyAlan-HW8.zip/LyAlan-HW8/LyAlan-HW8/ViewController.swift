//
//  ViewController.swift
// Project: LyAlan-HW8
// EID: al49725
// Course: CS371L

import UIKit
import UserNotifications

class ViewController: UIViewController {

    let towerImage = UIImage(named: "uttower")
    let logoImage = UIImage(named: "ut")
    
    @IBOutlet weak var mainImageButton: UIButton!
    var images:[UIImage] = []
    
    var index:Int = 0
        
    override func viewDidLoad() {
        super.viewDidLoad()
        images.append(towerImage!)
        images.append(logoImage!)
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]){(granted, error) in
            if granted{
                print("Permission Granted")
            }
            else if let error = error {
                print(error.localizedDescription)
            }
        }
    }

    @IBAction func imageChangeButton(_ sender: Any) {
        index+=1
        UIView.animate(withDuration: 1.0,
                       delay: 0,
                       options: .curveEaseOut,
                       animations: {self.mainImageButton.alpha = 0.0},
                       completion: {finish in self.mainImageButton.setImage(self.images[self.index % self.images.count], for: .normal);
            UIView.animate(withDuration: 1.0,
                           delay: 0,
                           options: .curveEaseIn,
                           animations: {self.mainImageButton.alpha = 1.0},
                           completion: nil)})
        if(index % 4 == 0){
            let content = UNMutableNotificationContent()
            content.title = "Click Count"
            content.subtitle = "Local Notif"
            content.body = "You have clicked 4 times"
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 8, repeats: false)
            let request = UNNotificationRequest(identifier: "Notif", content: content, trigger: trigger)
            
            UNUserNotificationCenter.current().add(request)
        }
    }
    
}

