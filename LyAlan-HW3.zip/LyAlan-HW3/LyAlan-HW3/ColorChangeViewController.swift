//
//  ColorChangeViewController.swift
// Project: LyAlan-HW3
// EID: al49725
// Course: CS371L
//

import UIKit

class ColorChangeViewController: UIViewController {
    var delegate: UIViewController!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    @IBAction func blueButtonPressed(_ sender: Any) {
        let lastVC = delegate as! TextChanger
        lastVC.changeColor(newColor: UIColor.blue)
    }
    
    @IBAction func redButtonPressed(_ sender: Any) {
        let lastVC = delegate as! TextChanger
        lastVC.changeColor(newColor: UIColor.red)
    }
}
