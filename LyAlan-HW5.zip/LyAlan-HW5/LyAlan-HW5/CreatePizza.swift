//
//  CreatePizza.swift
// Project: LyAlan-HW5
// EID: al49725
// Course: CS371L

import UIKit

class CreatePizza: UIViewController {

    @IBOutlet weak var sizeSeg: UISegmentedControl!
    @IBOutlet weak var crustButton: UIButton!
    @IBOutlet weak var cheeseButton: UIButton!
    @IBOutlet weak var meatButton: UIButton!
    @IBOutlet weak var veggieButton: UIButton!
    @IBOutlet weak var doneButton: UIButton!
    var delegate: UIViewController!

    var sizeType:String = "small"
    var crustType:String = ""
    var cheeseType:String = ""
    var meatType:String = ""
    var veggieType:String = ""
    
    @IBOutlet weak var pizzaSummary: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func crustPressed(_ sender: Any) {
        let controller = UIAlertController(
            title: "Select Crust",
            message: "Choose a crust type",
            preferredStyle: .alert)
        
        controller.addAction(UIAlertAction(
            title: "Thin Crust",
            style: .default) { action in self.crustType = "Thin Crust"})
        controller.addAction(UIAlertAction(
            title: "Thick Crust",
            style: .default) { action in self.crustType = "Thick Crust"})
        present(controller, animated: true)
    }
    
    @IBAction func cheesePressed(_ sender: Any) {
        let controller = UIAlertController(
            title: "Select cheese",
            message: "Choose a cheese type",
            preferredStyle: .actionSheet)
        
        controller.addAction(UIAlertAction(
            title: "Regular Cheese",
            style: .default) { action in self.cheeseType = "Regular Cheese"})
        controller.addAction(UIAlertAction(
            title: "No Cheese",
            style: .default) { action in self.cheeseType = "No Cheese"})
        controller.addAction(UIAlertAction(
            title: "Double Cheese",
            style: .default) { action in self.cheeseType = "Double Cheese"})
        present(controller, animated: true)
    }
    
    @IBAction func meatPressed(_ sender: Any) {
        let controller = UIAlertController(
            title: "Select meat",
            message: "Choose one meat",
            preferredStyle: .actionSheet)
        
        controller.addAction(UIAlertAction(
            title: "Pepperoni",
            style: .default) { action in self.meatType = "Pepperoni"})
        controller.addAction(UIAlertAction(
            title: "Sausage",
            style: .default) { action in self.meatType = "Sausage"})
        controller.addAction(UIAlertAction(
            title: "Canadian Bacon",
            style: .default) { action in self.meatType = "Canadian Bacon"})
        present(controller, animated: true)
    }
    
    @IBAction func veggiePressed(_ sender: Any) {
        let controller = UIAlertController(
            title: "Select veggies",
            message: "Choose your veggies",
            preferredStyle: .actionSheet)
        
        controller.addAction(UIAlertAction(
            title: "Mushroom",
            style: .default) { action in self.veggieType = "Mushroom"})
        controller.addAction(UIAlertAction(
            title: "Onion",
            style: .default) { action in self.veggieType = "Onion"})
        controller.addAction(UIAlertAction(
            title: "Green Olive",
            style: .default) { action in self.veggieType = "Green Olive"})
        controller.addAction(UIAlertAction(
            title: "Black Olive",
            style: .default) { action in self.veggieType = "Black Olive"})
        controller.addAction(UIAlertAction(
            title: "None",
            style: .default) { action in self.veggieType = "None"})
        present(controller, animated: true)
    }
    
    
    @IBAction func sizeChange(_ sender: Any) {
        switch sizeSeg.selectedSegmentIndex {
        case 0:
            sizeType = "small"
        case 1:
            sizeType = "medium"
        case 2:
            sizeType = "large"
        default:
            sizeType = ""
        }
    }
    
    @IBAction func donePressed(_ sender: Any) {
        if !checkMissingIngredients(){
            pizzaSummary.text =
            "One \(sizeType) pizza with:\n\t \(crustType)\n\t \(cheeseType)\n\t \(meatType)\n\t \(veggieType)"
            let lastVC = delegate as! TableManager
            lastVC.addPizza(pSize: sizeType, crust: crustType, cheese: cheeseType, meat: meatType, veggies: veggieType)
        }
    }
    
    func checkMissingIngredients()->Bool{
        var message:String = ""
        if crustType == ""{
            message = "crust"
        }
        else if cheeseType == ""{
            message = "cheese"
        }
        else if meatType == ""{
            message = "meat"
        }
        else if veggieType == ""{
            message = "veggie"
        }
        else{
            return false
        }
        let controller = UIAlertController(
            title: "Missing Ingredient",
            message: "Please select a \(message) type",
            preferredStyle: .alert)
        
        controller.addAction(UIAlertAction(
            title: "Ok",
            style: .default))
        present(controller, animated: true)
        return true
    }
}
