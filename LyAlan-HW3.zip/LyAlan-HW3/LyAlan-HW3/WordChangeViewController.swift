//
//  TextChangeViewController.swift
// Project: LyAlan-HW3
// EID: al49725
// Course: CS371L
//

import UIKit

class WordChangeViewController: UIViewController {
    
    @IBOutlet weak var wordInput: UITextField!
    var delegate: UIViewController!
    var prevName = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        wordInput.text = prevName
    }

    @IBAction func saveButton(_ sender: Any) {
        let lastVC = delegate as! TextChanger
        lastVC.changeText(newWord:wordInput.text!)
    }
    
}
