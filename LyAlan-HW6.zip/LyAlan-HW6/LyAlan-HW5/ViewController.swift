//
//  ViewController.swift
// Project: LyAlan-HW6
// EID: al49725
// Course: CS371L

import UIKit
import FirebaseAuth
import CoreData

let appDelegate = UIApplication.shared.delegate as! AppDelegate
let context = appDelegate.persistentContainer.viewContext

class Pizza {
    var pSize: String = ""
    var crust: String = ""
    var cheese: String = ""
    var meat: String = ""
    var veggies: String = ""
    
    init(pSize:String, crust:String, cheese:String, meat:String, veggies:String) {
        self.pSize = pSize
        self.crust = crust
        self.cheese = cheese
        self.meat = meat
        self.veggies = veggies
    }
    func showPizza()->String {
        return "\(pSize)\n\t \(crust)\n\t \(cheese)\n\t \(meat)\n\t \(veggies)"
    }
}

protocol TableManager {
    func addPizza(pSize:String, crust:String, cheese:String, meat:String, veggies:String)
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, TableManager {
    
    
    @IBOutlet weak var signOutButton: UIBarButtonItem!
    @IBOutlet weak var madePizzas: UITableView!
    let textCellIdentifier = "TextCell"

    var pizzaList:[Pizza] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        madePizzas.delegate = self
        madePizzas.dataSource = self
        let fetchedResults = retrievePizza()
        
        for pizza in fetchedResults {
            if let psize = pizza.value(forKey: "size") {
                if let crust = pizza.value(forKey: "crust") {
                    if let cheese = pizza.value(forKey: "cheese") {
                        if let meat = pizza.value(forKey: "meat") {
                            if let veggies = pizza.value(forKey: "veggies") {
                                addPizzaOnLoad(pSize: psize as! String, crust: crust as! String, cheese: cheese as! String, meat: meat as! String , veggies: veggies as! String)
                            }
                        }
                    }
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        madePizzas.reloadData()
    }
    
    func tableView(_ madePizzas: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pizzaList.count
    }
    
    func tableView(_ madePizzas: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = madePizzas.dequeueReusableCell(withIdentifier: textCellIdentifier, for:indexPath as IndexPath)
        let row = indexPath.row
        cell.textLabel?.text = pizzaList[row].showPizza()
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            deleteFromCoreData(pSize: pizzaList[indexPath.row].pSize, crust: pizzaList[indexPath.row].crust, cheese: pizzaList[indexPath.row].cheese, meat: pizzaList[indexPath.row].meat, veggies: pizzaList[indexPath.row].veggies)
            pizzaList.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }
        
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "PizzaScreen",
           let nextVC = segue.destination as? CreatePizza
        {
            nextVC.delegate = self
        }
    }
    
    func addPizza(pSize: String, crust: String, cheese: String, meat: String, veggies: String) {
        
        let newPizza = Pizza(pSize: pSize, crust: crust, cheese: cheese, meat: meat, veggies: veggies)
        pizzaList.append(newPizza)
        storePizza(pSize: pSize, crust: crust, cheese: cheese, meat: meat, veggies: veggies)
    }
    
    func addPizzaOnLoad(pSize: String, crust: String, cheese: String, meat: String, veggies: String){
        let newPizza = Pizza(pSize: pSize, crust: crust, cheese: cheese, meat: meat, veggies: veggies)
        pizzaList.append(newPizza)
    }
    
    func storePizza(pSize: String, crust: String, cheese: String, meat: String, veggies: String) {
        let pizza = NSEntityDescription.insertNewObject(forEntityName: "PizzaMade", into: context)
        pizza.setValue(pSize, forKey: "size")
        pizza.setValue(crust, forKey: "crust")
        pizza.setValue(cheese, forKey: "cheese")
        pizza.setValue(meat, forKey: "meat")
        pizza.setValue(veggies, forKey: "veggies")

        saveContext()
    }
    
    func saveContext () {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    func retrievePizza() -> [NSManagedObject] {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "PizzaMade")
        var fetchedResults:[NSManagedObject]? = nil
        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        } catch {
            print("Error occurred while retrieving data")
            abort()
        }
        return(fetchedResults)!
    }
    
    func deleteFromCoreData(pSize: String, crust: String, cheese: String, meat: String, veggies: String) {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "PizzaMade")
        var fetchedResults:[NSManagedObject]
        
        do {
            try fetchedResults = (context.fetch(request) as! [NSManagedObject])
                
            for pizza:AnyObject in fetchedResults {
                if pSize == pizza.value(forKey: "size") as? String {
                    if crust == pizza.value(forKey: "crust") as? String {
                        if cheese == pizza.value(forKey: "cheese") as? String {
                            if meat == pizza.value(forKey: "meat") as? String {
                                if veggies == pizza.value(forKey: "veggies") as? String {
                                    context.delete(pizza as! NSManagedObject)
                                    saveContext()
                                    return
                                }
                            }
                        }
                    }
                }
            }
            
        } catch {
            print("Error occurred while clearing data")
            abort()
        }
    }
    
    @IBAction func logOut(_ sender: Any) {
        do {
            try Auth.auth().signOut()
            self.dismiss(animated: true)
        } catch {
            print("Sign out error")
        }
    }
}

