//
//  ViewController.swift
// Project: LyAlan-HW9
// EID: al49725
// Course: CS371L

import UIKit

class ViewController: UIViewController {

    private var queue: DispatchQueue!

    var box:UIView!
    var startPosX = UIScreen.main.bounds.width * (4/9)
    var startPosY = UIScreen.main.bounds.height * (9/19)
    
    var moving:Bool = false
    var direction:String = "Up"
    
    var columnCount:Int = 4
    var rowCount:Int = 9
    
    var center:CGPoint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        box = UIView(frame: CGRect(x: startPosX, y: startPosY, width: UIScreen.main.bounds.width / 9, height: UIScreen.main.bounds.height / 19))
        box.backgroundColor = .green
        queue = DispatchQueue.global()
        
        let swipeRecognizerRight = UISwipeGestureRecognizer(target: self, action: #selector(recognizeSwipeGesture(recognizer:)))
        swipeRecognizerRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRecognizerRight)
        
        let swipeRecognizerLeft = UISwipeGestureRecognizer(target: self, action: #selector(recognizeSwipeGesture(recognizer:)))
        swipeRecognizerLeft.direction = UISwipeGestureRecognizer.Direction.left
        self.view.addGestureRecognizer(swipeRecognizerLeft)
        
        let swipeRecognizerUp = UISwipeGestureRecognizer(target: self, action: #selector(recognizeSwipeGesture(recognizer:)))
        swipeRecognizerUp.direction = UISwipeGestureRecognizer.Direction.up
        self.view.addGestureRecognizer(swipeRecognizerUp)
        
        let swipeRecognizerDown = UISwipeGestureRecognizer(target: self, action: #selector(recognizeSwipeGesture(recognizer:)))
        swipeRecognizerDown.direction = UISwipeGestureRecognizer.Direction.down
        self.view.addGestureRecognizer(swipeRecognizerDown)
        
        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(recognizeTapGesture(recognizer:)))
        box.addGestureRecognizer(tapRecognizer)
        self.view.addSubview(box)
        center = box.center
    }

    func moveBlock(){
        moving = true
        var x:Float = 0
        var y:Float = 0
        var counter:Int = 1
        queue.async {
            while self.moving {
                if self.direction == "Up"{
                    x = 0
                    y = -Float(UIScreen.main.bounds.height * (1/19))
                    counter = 1
                }
                else if self.direction == "Down"{
                    x = 0
                    y = Float(UIScreen.main.bounds.height * (1/19))
                    counter = -1
                }
                else if self.direction == "Right"{
                    x = Float(UIScreen.main.bounds.width * (1/9))
                    y = 0
                    counter = 1
                }
                else{
                    x = -Float(UIScreen.main.bounds.width * (1/9))
                    y = 0
                    counter = -1
                }
                // Not specified in the assignment. My implementation allows the block to move on the edge, but if you keep going, it will "crash"/ stop like the real game of snake. Wasn't sure if it was intended to stop THE MOMENT it touches the edge or not.
                if self.direction == "Up" || self.direction == "Down"{
                    self.rowCount+=counter
                }
                else{
                    self.columnCount+=counter
                }
                if self.columnCount == -1 || self.columnCount == 9 || self.rowCount == 0 || self.rowCount == 18{
                    DispatchQueue.main.async {
                        self.box.backgroundColor = .red
                        self.moving = false
                    }
                }
                else{
                    DispatchQueue.main.async {
                        self.box.center = CGPoint(x: self.box.center.x + CGFloat(x), y: self.box.center.y + CGFloat(y))
                    }
                }
                usleep(300000)
            }
        }
    }
    
    @IBAction func recognizeTapGesture(recognizer: UITapGestureRecognizer)
    {
        if !moving{
            box.backgroundColor = .green
            direction = "Down"
            box.center = center
            columnCount = 4
            rowCount = 9
            moveBlock()
        }
    }
    
    @IBAction func recognizeSwipeGesture(recognizer: UISwipeGestureRecognizer)
    {
        if(moving){
            if recognizer.direction == .right{
                direction = "Right"
            }
            else if recognizer.direction == .left{
                direction = "Left"
            }
            else if recognizer.direction == .up{
                direction = "Up"
            }
            else{
                direction = "Down"
            }
        }
    }
    
}

